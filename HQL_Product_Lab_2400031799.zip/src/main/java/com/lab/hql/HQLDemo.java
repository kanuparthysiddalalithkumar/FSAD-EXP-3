
package com.lab.hql;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

public class HQLDemo {

    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        session.save(new Product("Apple","Fruit",120,10));
        session.save(new Product("Banana","Fruit",60,20));
        session.save(new Product("Milk","Dairy",50,15));
        session.save(new Product("Cheese","Dairy",200,5));
        session.save(new Product("Rice","Grain",80,0));
        session.save(new Product("Wheat","Grain",70,25));

        tx.commit();

        // Sorting
        List<Product> asc = session.createQuery("from Product p order by p.price asc", Product.class).list();
        List<Product> desc = session.createQuery("from Product p order by p.price desc", Product.class).list();

        // Quantity sort
        session.createQuery("from Product p order by p.quantity desc", Product.class).list();

        // Pagination
        session.createQuery("from Product", Product.class).setFirstResult(0).setMaxResults(3).list();
        session.createQuery("from Product", Product.class).setFirstResult(3).setMaxResults(3).list();

        // Aggregates
        session.createQuery("select count(*) from Product").uniqueResult();
        session.createQuery("select count(*) from Product where quantity > 0").uniqueResult();
        session.createQuery("select description, count(*) from Product group by description").list();
        session.createQuery("select min(price), max(price) from Product").list();

        // Group By
        session.createQuery("from Product p group by p.description").list();

        // Where
        session.createQuery("from Product p where p.price between 50 and 150").list();

        // Like
        session.createQuery("from Product p where p.name like 'A%'").list();
        session.createQuery("from Product p where p.name like '%a'").list();
        session.createQuery("from Product p where p.name like '%ee%'").list();
        session.createQuery("from Product p where length(p.name)=5").list();

        session.close();
        HibernateUtil.getSessionFactory().close();
    }
}
